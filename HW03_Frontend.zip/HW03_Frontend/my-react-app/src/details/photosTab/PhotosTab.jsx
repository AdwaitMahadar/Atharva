import { Container, Row, Col } from 'react-bootstrap';
// import photoData from '../../data/photoData';

const PhotosTab = ({ photoData }) => {
  return (
    <Container>
      <Row>
        {photoData.links.map((link, index) => (
          <Col key={index} xs={12} md={6} lg={4}>
            <img src={link} alt={`Image ${index + 1}`} className="img-fluid" />
          </Col>
        ))}
      </Row>
    </Container>
  );
};

export default PhotosTab;
