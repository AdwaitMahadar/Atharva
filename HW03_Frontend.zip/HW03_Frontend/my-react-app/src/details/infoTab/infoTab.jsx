function extractData(data) {
  const productImages = data.Item.PictureURL;
  const price = data.Item.CurrentPrice.Value;
  const location = data.Item.Location;
  const returnPolicy = `${data.Item.ReturnPolicy.ReturnsAccepted} (${data.Item.ReturnPolicy.ReturnsWithin})`;
  const itemSpecifics = data.Item.ItemSpecifics.NameValueList;

  return {
    productImages,
    price,
    location,
    returnPolicy,
    itemSpecifics,
  };
}

function ProductTable({ detailInfo }) {
//   const extractedData = extractData(detailInfo);

  return (
    <table className="product-table">
      <tbody>
        {console.log(detailInfo)}
        {detailInfo.PictureURL?<tr>
          <td>Product Images</td>
          <td>{detailInfo.PictureURL}</td>
        </tr>: null}
        {detailInfo.CurrentPrice?<tr>
          <td>Price</td>
          <td>{detailInfo.CurrentPrice.Value}</td>
        </tr>:null}
        {detailInfo.Location?<tr>
          <td>Location</td>
          <td>{detailInfo.Location}</td>
        </tr>:null}
        {detailInfo.ReturnPolicy?<tr>
          <td>Return Policy (US)</td>
          <td>{detailInfo.ReturnPolicy.ReturnsAccepted + " Within " + detailInfo.ReturnPolicy.ReturnsWithin}</td>
        </tr>: null}
        {console.log("Item Specifics: " + detailInfo.ItemSpecifics)}
        {detailInfo.ItemSpecifics?.NameValueList? detailInfo.ItemSpecifics.NameValueList.map((itemSpecific, index) => ( 
          <tr key={index}>
            <td>
              <strong>{itemSpecific.Name}:</strong>
            </td>
            <td>
              {itemSpecific.Value.join(', ')}
            </td>
          </tr>
        )): <tr><td>Item Soecifics N/A</td></tr>}
      </tbody>
    </table>
  );
}

export default ProductTable;
