import { useState } from 'react';
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import ProductTable from './infoTab/infoTab';
import PhotosTab from './photosTab/PhotosTab';

const DetailsTab = ({detailInfo, photoData}) =>{
  const [key, setKey] = useState('home');

  return (
    <Tabs
      id="controlled-tab-example"
      activeKey={key}
      onSelect={(k) => setKey(k)}
      className="mb-3"
    >
      <Tab eventKey="home" title="Home">
        Tab content for Home
        <ProductTable detailInfo={detailInfo} />
      </Tab>
      <Tab eventKey="photos" title="Photos">
        <PhotosTab photoData={photoData} />
      </Tab>
      <Tab eventKey="shipping" title="Shipping">
        Tab content for Profile
      </Tab>
      <Tab eventKey="seller" title="Seller">
        Tab content for Profile
      </Tab>
      <Tab eventKey="similar products" title="Similar Products">
        Tab content for Profile
      </Tab>
    </Tabs>
  );
}

export default DetailsTab;