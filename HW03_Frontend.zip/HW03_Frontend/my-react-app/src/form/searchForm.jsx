// import React from "react";
// import { Form, FormControl, Button } from "react-bootstrap";
import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';


const ProductSearchForm = ({eBayAPICall}) => {
    // state for every input
    const [keyword, setKeyword] = useState('');
    // Handler for every input
    const handleKeywordChange = (e) => {
        console.log(e.target.value);
        setKeyword(e.target.value);
    };
    
    const [category, setCategory] = useState('');
    const handleCategoryChange = (e) => {
        console.log(e.target.value);
        setCategory(e.target.value);
    };

    const [news, setNews] = useState(false);
    const handleConditionNews = (e) => {
        console.log(e.target.value + " New");
        setNews(e.target.value);
    };

    const [used, setUsed] = useState(false);
    const handleConditionUsed = (e) => {
        console.log(e.target.value);
        setUsed(e.target.value);
    };

    const [unspecified, setUnspecified] = useState(false);
    const handleConditionUnspecified = (e) => {
        console.log(e.target.value);
        setUnspecified(e.target.value);
    };

    const [localPickup, setLocalPickup] = useState(false);
    const handleLocalPickup = (e) => {
        console.log(e.target.value);
        setLocalPickup(e.target.value);
    };

    const [freeShipping, setFreeShipping] = useState(false);
    const handleFreeShipping = (e) => {
        console.log(e.target.value);
        setFreeShipping(e.target.value);
    };

    const [distance, setDistance] = useState(10);
    const handleDistance = (e) => {
        console.log(e.target.value);
        setDistance(e.target.value);
    };

    const [currentLocation, setCurrentLocation] = useState(true);
    const handleCurrentLocation = (e) => {
        console.log(e.target.value);
        setCurrentLocation(e.target.value);
        setOtherZip({disabled: true, value: ''});

    };

    const [otherZip, setOtherZip] = useState({disabled: true, value: ''});
    const handleOtherZip = (e) => {
        console.log(e.target.value);
        setOtherZip({disabled: false, value: ''});
        setCurrentLocation(!currentLocation);
    };

    const handleLocation = (e) => {
        console.log(e.target.value);
        setOtherZip({disabled: false, value: e.target.value});
    };

    const handleSearch = (e) => {
        e.preventDefault();
        // handle validations if any
        eBayAPICall(
            keyword,
            category,
            news,
            used,
            unspecified,
            localPickup,
            freeShipping,
            distance,
            currentLocation,
            otherZip.value
        );
    }

  return (
    <Form onSubmit={handleSearch}>
      <Form.Group controlId="keyword">
        <Form.Label>Keyword</Form.Label>
        <input type="text" placeholder="Enter Product Name (eg. iPhone 8)" onChange={handleKeywordChange} value = {keyword} />
      </Form.Group>

      <Form.Group controlId="category">
        <Form.Label>Category</Form.Label>
        <Form.Control as="select" onChange={handleCategoryChange}>
          <option>All Categories</option>
          <option>Electronics</option>
          <option>Clothing</option>
          <option>Home & Garden</option>
        </Form.Control>
      </Form.Group>

      <Form.Group controlId="condition">
        <Form.Label>Condition</Form.Label>
        <Form.Check
          type="checkbox"
          name="condition"
          id="new"
          label="New"
          checked={news}
          onChange={handleConditionNews}
        />
        <Form.Check
          type="checkbox"
          name="condition"
          id="used"
          label="Used"
          checked={used}
          onChange={handleConditionUsed}
        />
        <Form.Check
          type="checkbox"
          name="condition"
          id="unspecified"
          label="Unspecified"
          checked={unspecified}
          onChange={handleConditionUnspecified}
        />
      </Form.Group>

      <Form.Group controlId="shippingOptions">
        <Form.Label>Shipping Options</Form.Label>
        <Form.Check
          type="checkbox"
          name="shippingOptions"
          id="localPickup"
          label="Local Pickup"
          checked={localPickup}
          onChange={handleLocalPickup}
        />
        <Form.Check
          type="checkbox"
          name="shippingOptions"
          id="freeShipping"
          label="Free Shipping"
          checked={freeShipping}
          onChange={handleFreeShipping}
        />
      </Form.Group>

      <Form.Group controlId="distance">
        <Form.Label>Distance (Miles)</Form.Label>
        <input 
        type="number" 
        onChange={handleDistance}
        value={distance} 
        />
      </Form.Group>

      <Form.Group controlId="from">
        <Form.Label>From</Form.Label>
        <Form.Check
          type="radio"
          name="currentLocation"
          id="currentLocation"
          label="'Current Location'"
          checked={currentLocation}
          onChange={handleCurrentLocation}
        />
        <Form.Check
          type="radio"
          name="otherZip"
          id="otherZipCheckbox"
          label="Other. Please specify zip code:"
          checked={!otherZip.disabled}
          onChange={handleOtherZip}
        />
        <input
          type="text"
          placeholder="Zip code"
          disabled={otherZip.disabled}
          value = {otherZip.value}
          onChange={handleLocation}
          
        />
      </Form.Group>

      <Button type="submit" >Search</Button>
      <Button type="reset">Clear</Button>
    </Form>
  );
};

export default ProductSearchForm;
