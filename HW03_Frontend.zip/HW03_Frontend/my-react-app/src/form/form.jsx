import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';

function HorizontalExample() {
  return (
    <Form>
        <Form.Label  >
            Product Search
        </Form.Label>
      <Row>
            <Col>
                <Form.Label  >
                    Keyword
                </Form.Label>
            </Col>
            <Col>
                <Form.Control  type="text" placeholder="Keyword" />
            </Col>
        </Row>

      <Row>
            <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
                <Col>
                <Form.Label column sm={2}>
                    Category
                </Form.Label>
                </Col>
                <Col>
                <Form.Select aria-label="Default select example">
                    <option default value="1">All Categories</option>
                    <option value="2">Art</option>
                    <option value="3">Baby</option>
                    <option value="3">Books</option>
                    <option value="3">Clothing,Shoes & Accessories</option>
                    <option value="3">Computers/Tablets & Networking</option>
                    <option value="3">Health & Beauty</option>
                    <option value="3">Music</option>
                    <option value="3">Video Games & Consoles</option>
                </Form.Select>
                </Col>
            </Form.Group>
      </Row>
      <Row>
      <fieldset>
        <Form.Group as={Row} className="mb-3">
          <Form.Label as="legend" column sm={2}>
            Condition
          </Form.Label>
          <Col sm={10}>
            <Form.Check
              type="checkbox"
              label="New"
              name="formHorizontalRadios"
              id="formHorizontalRadios1"
            />
            <Form.Check
              type="checkbox"
              label="Used"
              name="formHorizontalRadios"
              id="formHorizontalRadios2"
            />
            <Form.Check
              type="checkbox"
              label="Unspecified"
              name="formHorizontalRadios"
              id="formHorizontalRadios3"
            />
          </Col>
        </Form.Group>
      </fieldset>
      </Row>
      <Row>
            <fieldset>
                    <Form.Group as={Row} className="mb-3">
                        <Form.Label as="legend" column sm={2}>
                            Shipping
                        </Form.Label>
                        <Col sm={10}>
                            <Form.Check
                                type="checkbox"
                                label="Local Pickup"
                                name="formHorizontalRadios"
                                id="formHorizontalRadios1"
                            />
                            <Form.Check
                                type="checkbox"
                                label="Free Shipping"
                                name="formHorizontalRadios"
                                id="formHorizontalRadios2"
                            />
                        </Col>
                    </Form.Group>
            </fieldset>
      </Row>

      <Row>
        <Col>
            <Form.Label  >
                Distance (Miles)
            </Form.Label>
        </Col>
        <Col>
          <Form.Control  type="text" placeholder="Large text" />
        </Col>
      </Row>

      <Row>
          <Form.Group as={Row} className="mb-3">
            <Form.Label as="legend" column sm={2}>
                From
            </Form.Label>
            <Col sm={10}>
                <Form.Check
                    type="radio"
                    label="'Current Location'"
                    name="formHorizontalRadios"
                    id="formHorizontalRadios1"
                />
                <Form.Check
                    type="radio"
                    label="Other. Please specify zip code:"
                    name="formHorizontalRadios"
                    id="formHorizontalRadios2"
                />
            </Col>
          </Form.Group>
        </Row>

        <Row>
            <Col>
            </Col>
            <Col>
                <Form.Control  type="text" placeholder="Large text" />
            </Col>
        </Row>

        <Row>
            <Form.Group as={Row} className="mb-3">
                <Col sm={{ span: 10, offset: 2 }}>
                    <Button type="submit">Search</Button>
                </Col>
            </Form.Group>
      </Row>
    </Form>
  );
}

export default HorizontalExample;