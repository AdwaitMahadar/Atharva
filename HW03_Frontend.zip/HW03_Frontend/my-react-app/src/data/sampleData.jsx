const sampleData = {
    "findItemsAdvancedResponse": [
      {
        "ack": [
          "Success"
        ],
        "version": [
          "1.13.0"
        ],
        "timestamp": [
          "2023-10-29T05:30:30.436Z"
        ],
        "searchResult": [
          {
            "@count": "10",
            "item": [
              {
                "itemId": [
                  "363750680783"
                ],
                "title": [
                  "2-Pack Fitted 100% Soft Cotton Baby Boy Girl Crib Pack N Play Sheets Set 24\"x38\""
                ],
                "globalId": [
                  "EBAY-US"
                ],
                "primaryCategory": [
                  {
                    "categoryId": [
                      "180909"
                    ],
                    "categoryName": [
                      "Sheets & Sets"
                    ]
                  }
                ],
                "galleryURL": [
                  "https://i.ebayimg.com/thumbs/images/g/0tcAAOSw45FiOjns/s-l140.jpg"
                ],
                "viewItemURL": [
                  "https://www.ebay.com/itm/2-Pack-Fitted-100-Soft-Cotton-Baby-Boy-Girl-Crib-Pack-N-Play-Sheets-Set-24-x38-/363750680783?var=0"
                ],
                "autoPay": [
                  "true"
                ],
                "postalCode": [
                  "900**"
                ],
                "location": [
                  "Los Angeles,CA,USA"
                ],
                "country": [
                  "US"
                ],
                "shippingInfo": [
                  {
                    "shippingServiceCost": [
                      {
                        "@currencyId": "USD",
                        "__value__": "0.0"
                      }
                    ],
                    "shippingType": [
                      "Free"
                    ],
                    "shipToLocations": [
                      "Worldwide"
                    ],
                    "expeditedShipping": [
                      "false"
                    ],
                    "oneDayShippingAvailable": [
                      "false"
                    ],
                    "handlingTime": [
                      "1"
                    ]
                  }
                ],
                "sellingStatus": [
                  {
                    "currentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "9.95"
                      }
                    ],
                    "convertedCurrentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "9.95"
                      }
                    ],
                    "sellingState": [
                      "Active"
                    ],
                    "timeLeft": [
                      "P5DT15H14M6S"
                    ]
                  }
                ],
                "listingInfo": [
                  {
                    "bestOfferEnabled": [
                      "false"
                    ],
                    "buyItNowAvailable": [
                      "false"
                    ],
                    "startTime": [
                      "2022-03-03T21:44:36.000Z"
                    ],
                    "endTime": [
                      "2023-11-03T20:44:36.000Z"
                    ],
                    "listingType": [
                      "FixedPrice"
                    ],
                    "gift": [
                      "false"
                    ],
                    "watchCount": [
                      "31"
                    ]
                  }
                ],
                "returnsAccepted": [
                  "true"
                ],
                "distance": [
                  {
                    "@unit": "mi",
                    "__value__": "5.0"
                  }
                ],
                "condition": [
                  {
                    "conditionId": [
                      "1000"
                    ],
                    "conditionDisplayName": [
                      "New with tags"
                    ]
                  }
                ],
                "isMultiVariationListing": [
                  "true"
                ],
                "topRatedListing": [
                  "true"
                ]
              },
              {
                "itemId": [
                  "224624740119"
                ],
                "title": [
                  "Baby Girl Chinese Classic Mary Jane Floral Satin Brocade Shoes Sizes 5 ~ 10"
                ],
                "globalId": [
                  "EBAY-US"
                ],
                "primaryCategory": [
                  {
                    "categoryId": [
                      "147285"
                    ],
                    "categoryName": [
                      "Baby Shoes"
                    ]
                  }
                ],
                "galleryURL": [
                  "https://i.ebayimg.com/thumbs/images/g/4VgAAOSwkQNhUNcP/s-l140.jpg"
                ],
                "viewItemURL": [
                  "https://www.ebay.com/itm/Baby-Girl-Chinese-Classic-Mary-Jane-Floral-Satin-Brocade-Shoes-Sizes-5-10-/224624740119?var=523444440299"
                ],
                "autoPay": [
                  "true"
                ],
                "postalCode": [
                  "900**"
                ],
                "location": [
                  "Los Angeles,CA,USA"
                ],
                "country": [
                  "US"
                ],
                "shippingInfo": [
                  {
                    "shippingServiceCost": [
                      {
                        "@currencyId": "USD",
                        "__value__": "0.0"
                      }
                    ],
                    "shippingType": [
                      "Free"
                    ],
                    "shipToLocations": [
                      "Worldwide"
                    ],
                    "expeditedShipping": [
                      "false"
                    ],
                    "oneDayShippingAvailable": [
                      "false"
                    ],
                    "handlingTime": [
                      "1"
                    ]
                  }
                ],
                "sellingStatus": [
                  {
                    "currentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "8.45"
                      }
                    ],
                    "convertedCurrentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "8.45"
                      }
                    ],
                    "sellingState": [
                      "Active"
                    ],
                    "timeLeft": [
                      "P28DT16H0M21S"
                    ]
                  }
                ],
                "listingInfo": [
                  {
                    "bestOfferEnabled": [
                      "false"
                    ],
                    "buyItNowAvailable": [
                      "false"
                    ],
                    "startTime": [
                      "2021-09-26T20:30:51.000Z"
                    ],
                    "endTime": [
                      "2023-11-26T21:30:51.000Z"
                    ],
                    "listingType": [
                      "FixedPrice"
                    ],
                    "gift": [
                      "false"
                    ]
                  }
                ],
                "returnsAccepted": [
                  "true"
                ],
                "galleryPlusPictureURL": [
                  "https://galleryplus.ebayimg.com/ws/web/224624740119_1_0_1.jpg"
                ],
                "distance": [
                  {
                    "@unit": "mi",
                    "__value__": "5.0"
                  }
                ],
                "condition": [
                  {
                    "conditionId": [
                      "1000"
                    ],
                    "conditionDisplayName": [
                      "New with box"
                    ]
                  }
                ],
                "isMultiVariationListing": [
                  "true"
                ],
                "topRatedListing": [
                  "false"
                ]
              },
              {
                "itemId": [
                  "295347701608"
                ],
                "title": [
                  "Pets Dog Cat Baby Safety Gate Mesh Fence Magic Portable Guard Net Stairs Doors"
                ],
                "globalId": [
                  "EBAY-US"
                ],
                "primaryCategory": [
                  {
                    "categoryId": [
                      "20748"
                    ],
                    "categoryName": [
                      "Fences & Exercise Pens"
                    ]
                  }
                ],
                "galleryURL": [
                  "https://i.ebayimg.com/thumbs/images/g/UiYAAOSwAeFjd3sH/s-l140.jpg"
                ],
                "viewItemURL": [
                  "https://www.ebay.com/itm/Pets-Dog-Cat-Baby-Safety-Gate-Mesh-Fence-Magic-Portable-Guard-Net-Stairs-Doors-/295347701608"
                ],
                "autoPay": [
                  "false"
                ],
                "postalCode": [
                  "903**"
                ],
                "location": [
                  "Inglewood,CA,USA"
                ],
                "country": [
                  "US"
                ],
                "shippingInfo": [
                  {
                    "shippingServiceCost": [
                      {
                        "@currencyId": "USD",
                        "__value__": "0.0"
                      }
                    ],
                    "shippingType": [
                      "Free"
                    ],
                    "shipToLocations": [
                      "Worldwide"
                    ],
                    "expeditedShipping": [
                      "false"
                    ],
                    "oneDayShippingAvailable": [
                      "false"
                    ],
                    "handlingTime": [
                      "1"
                    ]
                  }
                ],
                "sellingStatus": [
                  {
                    "currentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "5.98"
                      }
                    ],
                    "convertedCurrentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "5.98"
                      }
                    ],
                    "sellingState": [
                      "Active"
                    ],
                    "timeLeft": [
                      "P20DT7H1M13S"
                    ]
                  }
                ],
                "listingInfo": [
                  {
                    "bestOfferEnabled": [
                      "false"
                    ],
                    "buyItNowAvailable": [
                      "false"
                    ],
                    "startTime": [
                      "2022-11-18T12:31:43.000Z"
                    ],
                    "endTime": [
                      "2023-11-18T12:31:43.000Z"
                    ],
                    "listingType": [
                      "FixedPrice"
                    ],
                    "gift": [
                      "false"
                    ],
                    "watchCount": [
                      "108"
                    ]
                  }
                ],
                "returnsAccepted": [
                  "true"
                ],
                "distance": [
                  {
                    "@unit": "mi",
                    "__value__": "5.0"
                  }
                ],
                "condition": [
                  {
                    "conditionId": [
                      "1000"
                    ],
                    "conditionDisplayName": [
                      "New"
                    ]
                  }
                ],
                "isMultiVariationListing": [
                  "false"
                ],
                "topRatedListing": [
                  "false"
                ]
              },
              {
                "itemId": [
                  "265545179398"
                ],
                "title": [
                  "Baby Wrist Rattle Baby Socks Rattle, Baby Finder Animal Toys Set Soft Animal Toy"
                ],
                "globalId": [
                  "EBAY-US"
                ],
                "primaryCategory": [
                  {
                    "categoryId": [
                      "100227"
                    ],
                    "categoryName": [
                      "Developmental Baby Toys"
                    ]
                  }
                ],
                "galleryURL": [
                  "https://i.ebayimg.com/thumbs/images/g/WoEAAOSwHZNiBrE9/s-l140.jpg"
                ],
                "viewItemURL": [
                  "https://www.ebay.com/itm/Baby-Wrist-Rattle-Baby-Socks-Rattle-Baby-Finder-Animal-Toys-Set-Soft-Animal-Toy-/265545179398"
                ],
                "autoPay": [
                  "true"
                ],
                "postalCode": [
                  "918**"
                ],
                "location": [
                  "Alhambra,CA,USA"
                ],
                "country": [
                  "US"
                ],
                "shippingInfo": [
                  {
                    "shippingServiceCost": [
                      {
                        "@currencyId": "USD",
                        "__value__": "0.0"
                      }
                    ],
                    "shippingType": [
                      "Free"
                    ],
                    "shipToLocations": [
                      "Worldwide"
                    ],
                    "expeditedShipping": [
                      "false"
                    ],
                    "oneDayShippingAvailable": [
                      "false"
                    ],
                    "handlingTime": [
                      "3"
                    ]
                  }
                ],
                "sellingStatus": [
                  {
                    "currentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "7.99"
                      }
                    ],
                    "convertedCurrentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "7.99"
                      }
                    ],
                    "sellingState": [
                      "Active"
                    ],
                    "timeLeft": [
                      "P13DT13H28M45S"
                    ]
                  }
                ],
                "listingInfo": [
                  {
                    "bestOfferEnabled": [
                      "false"
                    ],
                    "buyItNowAvailable": [
                      "false"
                    ],
                    "startTime": [
                      "2022-02-11T18:59:15.000Z"
                    ],
                    "endTime": [
                      "2023-11-11T18:59:15.000Z"
                    ],
                    "listingType": [
                      "FixedPrice"
                    ],
                    "gift": [
                      "false"
                    ],
                    "watchCount": [
                      "40"
                    ]
                  }
                ],
                "returnsAccepted": [
                  "true"
                ],
                "distance": [
                  {
                    "@unit": "mi",
                    "__value__": "10.0"
                  }
                ],
                "condition": [
                  {
                    "conditionId": [
                      "1000"
                    ],
                    "conditionDisplayName": [
                      "New"
                    ]
                  }
                ],
                "isMultiVariationListing": [
                  "false"
                ],
                "topRatedListing": [
                  "false"
                ]
              },
              {
                "itemId": [
                  "301888982471"
                ],
                "title": [
                  "Crochet Baby Booties Ribbon  Newborn Pink White Blue Unisex Size 0-3 Months Crib"
                ],
                "globalId": [
                  "EBAY-US"
                ],
                "primaryCategory": [
                  {
                    "categoryId": [
                      "147285"
                    ],
                    "categoryName": [
                      "Baby Shoes"
                    ]
                  }
                ],
                "galleryURL": [
                  "https://i.ebayimg.com/thumbs/images/g/7ZIAAOSw2bReOKQ9/s-l140.jpg"
                ],
                "viewItemURL": [
                  "https://www.ebay.com/itm/Crochet-Baby-Booties-Ribbon-Newborn-Pink-White-Blue-Unisex-Size-0-3-Months-Crib-/301888982471?var=0"
                ],
                "autoPay": [
                  "true"
                ],
                "postalCode": [
                  "900**"
                ],
                "location": [
                  "Los Angeles,CA,USA"
                ],
                "country": [
                  "US"
                ],
                "shippingInfo": [
                  {
                    "shippingServiceCost": [
                      {
                        "@currencyId": "USD",
                        "__value__": "0.0"
                      }
                    ],
                    "shippingType": [
                      "Free"
                    ],
                    "shipToLocations": [
                      "Worldwide"
                    ],
                    "expeditedShipping": [
                      "true"
                    ],
                    "oneDayShippingAvailable": [
                      "false"
                    ],
                    "handlingTime": [
                      "1"
                    ]
                  }
                ],
                "sellingStatus": [
                  {
                    "currentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "7.97"
                      }
                    ],
                    "convertedCurrentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "7.97"
                      }
                    ],
                    "sellingState": [
                      "Active"
                    ],
                    "timeLeft": [
                      "P6DT15H33M25S"
                    ]
                  }
                ],
                "listingInfo": [
                  {
                    "bestOfferEnabled": [
                      "false"
                    ],
                    "buyItNowAvailable": [
                      "false"
                    ],
                    "startTime": [
                      "2016-03-04T22:03:55.000Z"
                    ],
                    "endTime": [
                      "2023-11-04T21:03:55.000Z"
                    ],
                    "listingType": [
                      "FixedPrice"
                    ],
                    "gift": [
                      "false"
                    ],
                    "watchCount": [
                      "137"
                    ]
                  }
                ],
                "returnsAccepted": [
                  "true"
                ],
                "distance": [
                  {
                    "@unit": "mi",
                    "__value__": "5.0"
                  }
                ],
                "condition": [
                  {
                    "conditionId": [
                      "1500"
                    ],
                    "conditionDisplayName": [
                      "New without box"
                    ]
                  }
                ],
                "isMultiVariationListing": [
                  "true"
                ],
                "topRatedListing": [
                  "false"
                ]
              },
              {
                "itemId": [
                  "175456506198"
                ],
                "title": [
                  "Disney Baby Girl Minne Mouse Double Sided Baby Blanket with Printed Mink"
                ],
                "globalId": [
                  "EBAY-US"
                ],
                "primaryCategory": [
                  {
                    "categoryId": [
                      "3081"
                    ],
                    "categoryName": [
                      "Blankets & Throws"
                    ]
                  }
                ],
                "galleryURL": [
                  "https://i.ebayimg.com/thumbs/images/g/FY4AAOSw4vRk08sx/s-l140.jpg"
                ],
                "viewItemURL": [
                  "https://www.ebay.com/itm/Disney-Baby-Girl-Minne-Mouse-Double-Sided-Baby-Blanket-Printed-Mink-/175456506198"
                ],
                "autoPay": [
                  "true"
                ],
                "postalCode": [
                  "903**"
                ],
                "location": [
                  "Inglewood,CA,USA"
                ],
                "country": [
                  "US"
                ],
                "shippingInfo": [
                  {
                    "shippingServiceCost": [
                      {
                        "@currencyId": "USD",
                        "__value__": "0.0"
                      }
                    ],
                    "shippingType": [
                      "Free"
                    ],
                    "shipToLocations": [
                      "Worldwide"
                    ],
                    "expeditedShipping": [
                      "false"
                    ],
                    "oneDayShippingAvailable": [
                      "false"
                    ],
                    "handlingTime": [
                      "0"
                    ]
                  }
                ],
                "sellingStatus": [
                  {
                    "currentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "14.77"
                      }
                    ],
                    "convertedCurrentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "14.77"
                      }
                    ],
                    "sellingState": [
                      "Active"
                    ],
                    "timeLeft": [
                      "P21DT17H9M53S"
                    ]
                  }
                ],
                "listingInfo": [
                  {
                    "bestOfferEnabled": [
                      "false"
                    ],
                    "buyItNowAvailable": [
                      "false"
                    ],
                    "startTime": [
                      "2022-10-19T21:40:23.000Z"
                    ],
                    "endTime": [
                      "2023-11-19T22:40:23.000Z"
                    ],
                    "listingType": [
                      "FixedPrice"
                    ],
                    "gift": [
                      "false"
                    ],
                    "watchCount": [
                      "84"
                    ]
                  }
                ],
                "returnsAccepted": [
                  "true"
                ],
                "distance": [
                  {
                    "@unit": "mi",
                    "__value__": "5.0"
                  }
                ],
                "condition": [
                  {
                    "conditionId": [
                      "1000"
                    ],
                    "conditionDisplayName": [
                      "New with tags"
                    ]
                  }
                ],
                "isMultiVariationListing": [
                  "false"
                ],
                "topRatedListing": [
                  "true"
                ]
              },
              {
                "itemId": [
                  "144795857310"
                ],
                "title": [
                  "Baby Pillow Newborn Head Protection Infant Bedding Cushion Sleep Pad Antiroll"
                ],
                "globalId": [
                  "EBAY-US"
                ],
                "primaryCategory": [
                  {
                    "categoryId": [
                      "180907"
                    ],
                    "categoryName": [
                      "Bed Pillows"
                    ]
                  }
                ],
                "galleryURL": [
                  "https://i.ebayimg.com/thumbs/images/g/kr8AAOSwhHpjZTql/s-l140.jpg"
                ],
                "viewItemURL": [
                  "https://www.ebay.com/itm/Baby-Pillow-Newborn-Head-Protection-Infant-Bedding-Cushion-Sleep-Pad-Antiroll-/144795857310?var=444013928422"
                ],
                "autoPay": [
                  "false"
                ],
                "postalCode": [
                  "900**"
                ],
                "location": [
                  "Los Angeles,CA,USA"
                ],
                "country": [
                  "US"
                ],
                "shippingInfo": [
                  {
                    "shippingServiceCost": [
                      {
                        "@currencyId": "USD",
                        "__value__": "0.0"
                      }
                    ],
                    "shippingType": [
                      "Free"
                    ],
                    "shipToLocations": [
                      "Worldwide"
                    ],
                    "expeditedShipping": [
                      "false"
                    ],
                    "oneDayShippingAvailable": [
                      "false"
                    ],
                    "handlingTime": [
                      "1"
                    ]
                  }
                ],
                "sellingStatus": [
                  {
                    "currentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "18.99"
                      }
                    ],
                    "convertedCurrentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "18.99"
                      }
                    ],
                    "sellingState": [
                      "Active"
                    ],
                    "timeLeft": [
                      "P6DT10H48M43S"
                    ]
                  }
                ],
                "listingInfo": [
                  {
                    "bestOfferEnabled": [
                      "false"
                    ],
                    "buyItNowAvailable": [
                      "false"
                    ],
                    "startTime": [
                      "2022-11-04T16:19:13.000Z"
                    ],
                    "endTime": [
                      "2023-11-04T16:19:13.000Z"
                    ],
                    "listingType": [
                      "FixedPrice"
                    ],
                    "gift": [
                      "false"
                    ]
                  }
                ],
                "returnsAccepted": [
                  "true"
                ],
                "distance": [
                  {
                    "@unit": "mi",
                    "__value__": "10.0"
                  }
                ],
                "condition": [
                  {
                    "conditionId": [
                      "1000"
                    ],
                    "conditionDisplayName": [
                      "New with tags"
                    ]
                  }
                ],
                "isMultiVariationListing": [
                  "true"
                ],
                "topRatedListing": [
                  "true"
                ]
              },
              {
                "itemId": [
                  "305217221081"
                ],
                "title": [
                  "VTech VM5254 5\" Video Baby Monitor+Camera Video SET NEW NO BOX"
                ],
                "globalId": [
                  "EBAY-US"
                ],
                "primaryCategory": [
                  {
                    "categoryId": [
                      "20435"
                    ],
                    "categoryName": [
                      "Baby Monitors"
                    ]
                  }
                ],
                "galleryURL": [
                  "https://i.ebayimg.com/thumbs/images/g/iI8AAOSwhhJjbUDb/s-l140.jpg"
                ],
                "viewItemURL": [
                  "https://www.ebay.com/itm/VTech-VM5254-5-Video-Baby-Monitor-Camera-Video-SET-NEW-NO-BOX-/305217221081"
                ],
                "productId": [
                  {
                    "@type": "ReferenceID",
                    "__value__": "12044161320"
                  }
                ],
                "autoPay": [
                  "true"
                ],
                "postalCode": [
                  "900**"
                ],
                "location": [
                  "Los Angeles,CA,USA"
                ],
                "country": [
                  "US"
                ],
                "shippingInfo": [
                  {
                    "shippingServiceCost": [
                      {
                        "@currencyId": "USD",
                        "__value__": "0.0"
                      }
                    ],
                    "shippingType": [
                      "Free"
                    ],
                    "shipToLocations": [
                      "Worldwide"
                    ],
                    "expeditedShipping": [
                      "false"
                    ],
                    "oneDayShippingAvailable": [
                      "false"
                    ],
                    "handlingTime": [
                      "1"
                    ]
                  }
                ],
                "sellingStatus": [
                  {
                    "currentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "35.99"
                      }
                    ],
                    "convertedCurrentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "35.99"
                      }
                    ],
                    "sellingState": [
                      "Active"
                    ],
                    "timeLeft": [
                      "P22DT11H18M56S"
                    ]
                  }
                ],
                "listingInfo": [
                  {
                    "bestOfferEnabled": [
                      "false"
                    ],
                    "buyItNowAvailable": [
                      "false"
                    ],
                    "startTime": [
                      "2023-10-20T16:49:26.000Z"
                    ],
                    "endTime": [
                      "2023-11-20T16:49:26.000Z"
                    ],
                    "listingType": [
                      "FixedPrice"
                    ],
                    "gift": [
                      "false"
                    ],
                    "watchCount": [
                      "4"
                    ]
                  }
                ],
                "returnsAccepted": [
                  "true"
                ],
                "distance": [
                  {
                    "@unit": "mi",
                    "__value__": "10.0"
                  }
                ],
                "condition": [
                  {
                    "conditionId": [
                      "1500"
                    ],
                    "conditionDisplayName": [
                      "New other (see details)"
                    ]
                  }
                ],
                "isMultiVariationListing": [
                  "false"
                ],
                "topRatedListing": [
                  "false"
                ]
              },
              {
                "itemId": [
                  "301092055500"
                ],
                "title": [
                  "Baby Crochet Boy Blue Hat and Cardigan Sweater Pants Booties 4 Piece Outfit Set"
                ],
                "globalId": [
                  "EBAY-US"
                ],
                "primaryCategory": [
                  {
                    "categoryId": [
                      "260024"
                    ],
                    "categoryName": [
                      "Outfits & Sets"
                    ]
                  }
                ],
                "galleryURL": [
                  "https://i.ebayimg.com/thumbs/images/g/AsAAAOSwMWNbtnq8/s-l140.jpg"
                ],
                "viewItemURL": [
                  "https://www.ebay.com/itm/Baby-Crochet-Boy-Blue-Hat-and-Cardigan-Sweater-Pants-Booties-4-Piece-Outfit-Set-/301092055500?var=600206971100"
                ],
                "autoPay": [
                  "true"
                ],
                "postalCode": [
                  "900**"
                ],
                "location": [
                  "Los Angeles,CA,USA"
                ],
                "country": [
                  "US"
                ],
                "shippingInfo": [
                  {
                    "shippingServiceCost": [
                      {
                        "@currencyId": "USD",
                        "__value__": "0.0"
                      }
                    ],
                    "shippingType": [
                      "Free"
                    ],
                    "shipToLocations": [
                      "Worldwide"
                    ],
                    "expeditedShipping": [
                      "false"
                    ],
                    "oneDayShippingAvailable": [
                      "false"
                    ],
                    "handlingTime": [
                      "1"
                    ]
                  }
                ],
                "sellingStatus": [
                  {
                    "currentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "16.99"
                      }
                    ],
                    "convertedCurrentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "16.99"
                      }
                    ],
                    "sellingState": [
                      "Active"
                    ],
                    "timeLeft": [
                      "P9DT16H31M59S"
                    ]
                  }
                ],
                "listingInfo": [
                  {
                    "bestOfferEnabled": [
                      "false"
                    ],
                    "buyItNowAvailable": [
                      "false"
                    ],
                    "startTime": [
                      "2014-02-07T22:02:29.000Z"
                    ],
                    "endTime": [
                      "2023-11-07T22:02:29.000Z"
                    ],
                    "listingType": [
                      "FixedPrice"
                    ],
                    "gift": [
                      "false"
                    ],
                    "watchCount": [
                      "92"
                    ]
                  }
                ],
                "returnsAccepted": [
                  "true"
                ],
                "distance": [
                  {
                    "@unit": "mi",
                    "__value__": "5.0"
                  }
                ],
                "condition": [
                  {
                    "conditionId": [
                      "1000"
                    ],
                    "conditionDisplayName": [
                      "New with tags"
                    ]
                  }
                ],
                "isMultiVariationListing": [
                  "true"
                ],
                "topRatedListing": [
                  "false"
                ]
              },
              {
                "itemId": [
                  "402797511014"
                ],
                "title": [
                  "TOYS FOR 2-10 Year Old Kids LED Night Light Star Moon Constellation US Baby Gift"
                ],
                "globalId": [
                  "EBAY-US"
                ],
                "primaryCategory": [
                  {
                    "categoryId": [
                      "100227"
                    ],
                    "categoryName": [
                      "Developmental Baby Toys"
                    ]
                  }
                ],
                "secondaryCategory": [
                  {
                    "categoryId": [
                      "20702"
                    ],
                    "categoryName": [
                      "Night Lights"
                    ]
                  }
                ],
                "galleryURL": [
                  "https://i.ebayimg.com/thumbs/images/g/284AAOSwasliociL/s-l140.jpg"
                ],
                "viewItemURL": [
                  "https://www.ebay.com/itm/TOYS-2-10-Year-Old-Kids-LED-Night-Light-Star-Moon-Constellation-US-Baby-Gift-/402797511014?var=0"
                ],
                "autoPay": [
                  "false"
                ],
                "postalCode": [
                  "900**"
                ],
                "location": [
                  "Los Angeles,CA,USA"
                ],
                "country": [
                  "US"
                ],
                "shippingInfo": [
                  {
                    "shippingServiceCost": [
                      {
                        "@currencyId": "USD",
                        "__value__": "0.0"
                      }
                    ],
                    "shippingType": [
                      "Free"
                    ],
                    "shipToLocations": [
                      "Worldwide"
                    ],
                    "expeditedShipping": [
                      "false"
                    ],
                    "oneDayShippingAvailable": [
                      "false"
                    ],
                    "handlingTime": [
                      "1"
                    ]
                  }
                ],
                "sellingStatus": [
                  {
                    "currentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "11.95"
                      }
                    ],
                    "convertedCurrentPrice": [
                      {
                        "@currencyId": "USD",
                        "__value__": "11.95"
                      }
                    ],
                    "sellingState": [
                      "Active"
                    ],
                    "timeLeft": [
                      "P19DT11H17M43S"
                    ]
                  }
                ],
                "listingInfo": [
                  {
                    "bestOfferEnabled": [
                      "false"
                    ],
                    "buyItNowAvailable": [
                      "false"
                    ],
                    "startTime": [
                      "2021-04-17T15:48:13.000Z"
                    ],
                    "endTime": [
                      "2023-11-17T16:48:13.000Z"
                    ],
                    "listingType": [
                      "FixedPrice"
                    ],
                    "gift": [
                      "false"
                    ],
                    "watchCount": [
                      "63"
                    ]
                  }
                ],
                "returnsAccepted": [
                  "true"
                ],
                "distance": [
                  {
                    "@unit": "mi",
                    "__value__": "5.0"
                  }
                ],
                "condition": [
                  {
                    "conditionId": [
                      "1000"
                    ],
                    "conditionDisplayName": [
                      "New"
                    ]
                  }
                ],
                "isMultiVariationListing": [
                  "true"
                ],
                "topRatedListing": [
                  "false"
                ]
              }
            ]
          }
        ],
        "paginationOutput": [
          {
            "pageNumber": [
              "1"
            ],
            "entriesPerPage": [
              "10"
            ],
            "totalPages": [
              "17437"
            ],
            "totalEntries": [
              "174364"
            ]
          }
        ],
        "itemSearchURL": [
          "https://www.ebay.com/sch/i.html?LH_FS=1&LH_Distance=90007..10&_nkw=Baby&_ddo=1&_fpos=90007&_fspt=1&_ipg=10&_pgn=1&_pos=90007&_sadis=10&_stpos=90007"
        ]
      }
    ]
  };

  const extractedData = sampleData.findItemsAdvancedResponse[0].searchResult[0].item.map((item) => {
    return {
      itemId: item.itemId[0],
      title: item.title[0],
      globalId: item.globalId[0],
      categoryId: item.primaryCategory[0].categoryId[0],
      categoryName: item.primaryCategory[0].categoryName[0],
      galleryURL: item.galleryURL[0],
      viewItemURL: item.viewItemURL[0],
      postalCode: item.postalCode[0],
      location: item.location[0],
      country: item.country[0],
      shippingInfo: {
        shippingServiceCost: item.shippingInfo[0].shippingServiceCost[0]["__value__"],
        shippingType: item.shippingInfo[0].shippingType[0],
        shipToLocations: item.shippingInfo[0].shipToLocations[0],
        expeditedShipping: item.shippingInfo[0].expeditedShipping[0],
        oneDayShippingAvailable: item.shippingInfo[0].oneDayShippingAvailable[0],
        handlingTime: item.shippingInfo[0].handlingTime[0],
      },
      sellingStatus: {
        currentPrice: item.sellingStatus[0].currentPrice[0]["__value__"],
        convertedCurrentPrice: item.sellingStatus[0].convertedCurrentPrice[0]["__value__"],
        sellingState: item.sellingStatus[0].sellingState[0],
        timeLeft: item.sellingStatus[0].timeLeft[0],
      },
      listingInfo: {
        bestOfferEnabled: item.listingInfo[0].bestOfferEnabled[0],
        buyItNowAvailable: item.listingInfo[0].buyItNowAvailable[0],
        startTime: item.listingInfo[0].startTime[0],
        endTime: item.listingInfo[0].endTime[0],
        listingType: item.listingInfo[0].listingType[0],
        gift: item.listingInfo[0].gift[0],
        // watchCount: item.listingInfo[0].watchCount[0],
      },
      returnsAccepted: item.returnsAccepted[0],
      distance: item.distance[0]["__value__"],
      condition: {
        conditionId: item.condition[0].conditionId[0],
        conditionDisplayName: item.condition[0].conditionDisplayName[0],
      },
      isMultiVariationListing: item.isMultiVariationListing[0],
      topRatedListing: item.topRatedListing[0],
    };
  });


//   // Extract all mentioned data for all items
// const extractedData = sampleData.findItemsAdvancedResponse[0].searchResult[0].item.map(item => ({
//     itemId: item.itemId[0],
//     title: item.title[0],
//     globalId: item.globalId[0],
//     categoryId: item.primaryCategory[0].categoryId[0],
//     categoryName: item.primaryCategory[0].categoryName[0],
//     galleryURL: item.galleryURL[0],
//     viewItemURL: item.viewItemURL[0],
//     postalCode: item.postalCode[0],
//     location: item.location[0],
//     country: item.country[0],
//     shippingInfo: {
//       shippingServiceCost: item.shippingInfo[0].shippingServiceCost[0].__value__,
//       shippingType: item.shippingInfo[0].shippingType[0],
//       shipToLocations: item.shippingInfo[0].shipToLocations[0],
//       expeditedShipping: item.shippingInfo[0].expeditedShipping[0],
//       oneDayShippingAvailable: item.shippingInfo[0].oneDayShippingAvailable[0],
//       handlingTime: item.shippingInfo[0].handlingTime[0]
//     },
//     sellingStatus: {
//       currentPrice: {
//         currencyId: item.sellingStatus[0].currentPrice[0]["@currencyId"],
//         value: item.sellingStatus[0].currentPrice[0]["__value__"]
//       },
//       convertedCurrentPrice: {
//         currencyId: item.sellingStatus[0].convertedCurrentPrice[0]["@currencyId"],
//         value: item.sellingStatus[0].convertedCurrentPrice[0]["__value__"]
//       },
//       sellingState: item.sellingStatus[0].sellingState[0],
//       timeLeft: item.sellingStatus[0].timeLeft[0]
//     },
//     listingInfo: {
//       bestOfferEnabled: item.listingInfo[0].bestOfferEnabled[0],
//       buyItNowAvailable: item.listingInfo[0].buyItNowAvailable[0],
//       startTime: item.listingInfo[0].startTime[0],
//       endTime: item.listingInfo[0].endTime[0],
//       listingType: item.listingInfo[0].listingType[0],
//       gift: item.listingInfo[0].gift[0],
//     //   watchCount: item.listingInfo[0].watchCount[0]
//     },
//     returnsAccepted: item.returnsAccepted[0],
//     distance: item.distance[0]["__value__"],
//     condition: {
//       conditionId: item.condition[0].conditionId[0],
//       conditionDisplayName: item.condition[0].conditionDisplayName[0]
//     },
//     isMultiVariationListing: item.isMultiVariationListing[0],
//     topRatedListing: item.topRatedListing[0]
//   }));
  

// export default  sampleData
  export default extractedData; // Export as a JSON string
  