export const detailInfo = {
    "Timestamp": "2023-10-31T04:09:30.359Z",
    "Ack": "Success",
    "Build": "1299_CORE_APILW_19146596_R1",
    "Version": "1299",
    "Item": {
      "BestOfferEnabled": true,
      "Description": "<p>Nike ACG Prylocast Men Size 13 ACG Hiking 385043-002 Black/Grey. Condition is Brand new with no original box. Shipped with USPS Priority Mail. All sales final. Thanks!</p>",
      "ItemID": "132961484706",
      "EndTime": "2019-03-08T00:46:16.000Z",
      "StartTime": "2019-02-21T15:47:18.000Z",
      "ViewItemURLForNaturalSearch": "https://www.ebay.com/itm/Nike-ACG-Prylocast-Brand-NewMen-Size-13-Trainerendor-Hiking-385043-002-Black-/132961484706",
      "ListingType": "FixedPriceItem",
      "Location": "Los Angeles, California",
      "PaymentMethods": [
        "PayPal"
      ],
      "GalleryURL": "https://i.ebayimg.com/00/s/MTYwMFgxMjAw/z/wYkAAOSws3dcZKr1/$_12.JPG?set_id=880000500F",
      "PictureURL": [
        "https://i.ebayimg.com/00/s/MTYwMFgxMjAw/z/wYkAAOSws3dcZKr1/$_12.JPG?set_id=880000500F",
        "https://i.ebayimg.com/00/s/MTYwMFgxMjAw/z/8fcAAOSwxL1cZKr3/$_12.JPG?set_id=880000500F",
        "https://i.ebayimg.com/00/s/MTYwMFgxMjAw/z/LQoAAOSw4S1cZKr6/$_12.JPG?set_id=880000500F",
        "https://i.ebayimg.com/00/s/MTYwMFgxMjAw/z/bKEAAOSwT9hcZKr8/$_12.JPG?set_id=880000500F",
        "https://i.ebayimg.com/00/s/MTYwMFgxMjAw/z/xGoAAOSwb-JcZKr-/$_12.JPG?set_id=880000500F",
        "https://i.ebayimg.com/00/s/MTYwMFgxMjAw/z/QDoAAOSwulFcZKsA/$_12.JPG?set_id=880000500F",
        "https://i.ebayimg.com/00/s/MTYwMFgxMjAw/z/2PcAAOSwtM9cZKsD/$_12.JPG?set_id=880000500F"
      ],
      "PostalCode": "900**",
      "PrimaryCategoryID": "15709",
      "PrimaryCategoryName": "Clothing, Shoes & Accessories:Men:Men's Shoes:Athletic Shoes",
      "Quantity": 1,
      "Seller": {
        "UserID": "sherrymorn33",
        "FeedbackRatingStar": "Turquoise",
        "FeedbackScore": 176,
        "PositiveFeedbackPercent": 100
      },
      "BidCount": 0,
      "ConvertedCurrentPrice": {
        "Value": 59.99,
        "CurrencyID": "USD"
      },
      "CurrentPrice": {
        "Value": 59.99,
        "CurrencyID": "USD"
      },
      "HighBidder": {
        "UserID": "c***a",
        "FeedbackPrivate": false,
        "FeedbackRatingStar": "Turquoise",
        "FeedbackScore": 136
      },
      "ListingStatus": "Completed",
      "QuantitySold": 1,
      "ShipToLocations": [
        "US"
      ],
      "Site": "US",
      "TimeLeft": "PT0S",
      "Title": "Nike ACG Prylocast Brand NewMen Size 13 Trainerendor Hiking 385043-002 Black",
      "ItemSpecifics": {
        "NameValueList": [
          {
            "Name": "Product Line",
            "Value": [
              "SB"
            ]
          },
          {
            "Name": "Brand",
            "Value": [
              "Nike"
            ]
          },
          {
            "Name": "US Shoe Size (Men's)",
            "Value": [
              "13"
            ]
          },
          {
            "Name": "Style",
            "Value": [
              "Hiking Shoes"
            ]
          },
          {
            "Name": "Euro Size",
            "Value": [
              "EUR 48,5"
            ]
          },
          {
            "Name": "Width",
            "Value": [
              "Medium (D, M)"
            ]
          },
          {
            "Name": "Color",
            "Value": [
              "Black"
            ]
          }
        ]
      },
      "PrimaryCategoryIDPath": "11450:260012:93427:15709",
      "Country": "US",
      "ReturnPolicy": {
        "ReturnsAccepted": "ReturnsNotAccepted"
      },
      "AutoPay": true,
      "PaymentAllowedSite": [
        
      ],
      "IntegratedMerchantCreditCardEnabled": false,
      "HandlingTime": 2,
      "ConditionID": 1500,
      "ConditionDisplayName": "New without box",
      "GlobalShipping": false,
      "QuantitySoldByPickupInStore": 0,
      "NewBestOffer": false
    }
  }

  export default detailInfo;