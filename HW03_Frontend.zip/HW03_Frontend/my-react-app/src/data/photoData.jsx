const jsonData = {
    "kind": "customsearch#search",
    "url": {
      "type": "application/json",
      "template": "https://www.googleapis.com/customsearch/v1?q={searchTerms}&num={count?}&start={startIndex?}&lr={language?}&safe={safe?}&cx={cx?}&sort={sort?}&filter={filter?}&gl={gl?}&cr={cr?}&googlehost={googleHost?}&c2coff={disableCnTwTranslation?}&hq={hq?}&hl={hl?}&siteSearch={siteSearch?}&siteSearchFilter={siteSearchFilter?}&exactTerms={exactTerms?}&excludeTerms={excludeTerms?}&linkSite={linkSite?}&orTerms={orTerms?}&relatedSite={relatedSite?}&dateRestrict={dateRestrict?}&lowRange={lowRange?}&highRange={highRange?}&searchType={searchType}&fileType={fileType?}&rights={rights?}&imgSize={imgSize?}&imgType={imgType?}&imgColorType={imgColorType?}&imgDominantColor={imgDominantColor?}&alt=json"
    },
    "queries": {
      "request": [
        {
          "title": "Google Custom Search - iphone SE",
          "totalResults": "2260000000",
          "searchTerms": "iphone SE",
          "count": 8,
          "startIndex": 1,
          "inputEncoding": "utf8",
          "outputEncoding": "utf8",
          "safe": "off",
          "cx": "f32b904abaadc4599",
          "searchType": "image",
          "imgSize": "huge"
        }
      ],
      "nextPage": [
        {
          "title": "Google Custom Search - iphone SE",
          "totalResults": "2260000000",
          "searchTerms": "iphone SE",
          "count": 8,
          "startIndex": 9,
          "inputEncoding": "utf8",
          "outputEncoding": "utf8",
          "safe": "off",
          "cx": "f32b904abaadc4599",
          "searchType": "image",
          "imgSize": "huge"
        }
      ]
    },
    "context": {
      "title": "MySearchEngine"
    },
    "searchInformation": {
      "searchTime": 0.898123,
      "formattedSearchTime": "0.90",
      "totalResults": "2260000000",
      "formattedTotalResults": "2,260,000,000"
    },
    "items": [
      {
        "kind": "customsearch#result",
        "title": "Apple iPhone SE (2022) Review: Powerful but Dated | WIRED",
        "htmlTitle": "<b>Apple iPhone SE</b> (2022) Review: Powerful but Dated | WIRED",
        "link": "https://media.wired.com/photos/6230ff3f44425e17cb3601cf/master/w_2560%2Cc_limit/Apple-iPhone-SE-Colors-Gear.jpg",
        "displayLink": "www.wired.com",
        "snippet": "Apple iPhone SE (2022) Review: Powerful but Dated | WIRED",
        "htmlSnippet": "<b>Apple iPhone SE</b> (2022) Review: Powerful but Dated | WIRED",
        "mime": "image/jpeg",
        "fileFormat": "image/jpeg",
        "image": {
          "contextLink": "https://www.wired.com/review/apple-iphone-se-2022/",
          "height": 1800,
          "width": 2400,
          "byteSize": 109663,
          "thumbnailLink": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTnZRcsIdzouQf9gVk0jH9OWU8q6ir6-pZ4_uVzlUq6MQK3FzbHGbMKng&s",
          "thumbnailHeight": 113,
          "thumbnailWidth": 150
        }
      },
      {
        "kind": "customsearch#result",
        "title": "Apple iPhone SE (2022) review: small size, big value | Digital Trends",
        "htmlTitle": "<b>Apple iPhone SE</b> (2022) review: small size, big value | Digital Trends",
        "link": "https://www.digitaltrends.com/wp-content/uploads/2022/08/iPhone-SE-2022-Starlight-Back-in-Hand.jpg?p=1",
        "displayLink": "www.digitaltrends.com",
        "snippet": "Apple iPhone SE (2022) review: small size, big value | Digital Trends",
        "htmlSnippet": "<b>Apple iPhone SE</b> (2022) review: small size, big value | Digital Trends",
        "mime": "image/jpeg",
        "fileFormat": "image/jpeg",
        "image": {
          "contextLink": "https://www.digitaltrends.com/mobile/iphone-se-2022-review/",
          "height": 2000,
          "width": 3000,
          "byteSize": 1114374,
          "thumbnailLink": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQUIjCEvP_JaDTwx6i-IYr5avdp_EopDkBxI5Y1FBlbvhDvpeG_vEuuAA&s",
          "thumbnailHeight": 100,
          "thumbnailWidth": 150
        }
      },
      {
        "kind": "customsearch#result",
        "title": "Amazon.com: Apple 2022 iPhone SE (64 GB, Starlight) [Locked] + ...",
        "htmlTitle": "Amazon.com: <b>Apple</b> 2022 <b>iPhone SE</b> (64 GB, Starlight) [Locked] + ...",
        "link": "https://m.media-amazon.com/images/I/61-MT8AQAPL.jpg",
        "displayLink": "www.amazon.com",
        "snippet": "Amazon.com: Apple 2022 iPhone SE (64 GB, Starlight) [Locked] + ...",
        "htmlSnippet": "Amazon.com: <b>Apple</b> 2022 <b>iPhone SE</b> (64 GB, Starlight) [Locked] + ...",
        "mime": "image/jpeg",
        "fileFormat": "image/jpeg",
        "image": {
          "contextLink": "https://www.amazon.com/Apple-iPhone-Starlight-Carrier-Subscription/dp/B09V4KJTTJ",
          "height": 2560,
          "width": 2560,
          "byteSize": 109390,
          "thumbnailLink": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQlmVVRgytsUJyF5uw3PnT3OD8ijS4JR3W4YQKepQLKaXDnnBZZjywYTpWw&s",
          "thumbnailHeight": 150,
          "thumbnailWidth": 150
        }
      },
      {
        "kind": "customsearch#result",
        "title": "Apple announces the new iPhone SE: a powerful smartphone in an ...",
        "htmlTitle": "<b>Apple</b> announces the new <b>iPhone SE</b>: a powerful smartphone in an ...",
        "link": "https://www.apple.com/newsroom/images/product/iphone/standard/Apple-iPhoneSE-color-lineup-4up-220308_big.jpg.slideshow-large_2x.jpg",
        "displayLink": "www.apple.com",
        "snippet": "Apple announces the new iPhone SE: a powerful smartphone in an ...",
        "htmlSnippet": "<b>Apple</b> announces the new <b>iPhone SE</b>: a powerful smartphone in an ...",
        "mime": "image/jpeg",
        "fileFormat": "image/jpeg",
        "image": {
          "contextLink": "https://www.apple.com/newsroom/2022/03/apple-announces-the-new-iphone-se-a-powerful-smartphone-in-an-iconic-design/",
          "height": 1698,
          "width": 2548,
          "byteSize": 210630,
          "thumbnailLink": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTd1lpWEnQ03D4T1XnpRyA_vYVYlFuXFt9cNW8gPLpLcuKT73o9svc6Bg&s",
          "thumbnailHeight": 100,
          "thumbnailWidth": 150
        }
      },
      {
        "kind": "customsearch#result",
        "title": "iPhone SE in Apple iPhone - Walmart.com",
        "htmlTitle": "<b>iPhone SE</b> in <b>Apple iPhone</b> - Walmart.com",
        "link": "https://i5.walmartimages.com/seo/Restored-Apple-iPhone-SE-2020-64GB-GSM-CDMA-Fully-Unlocked-Phone-Red-Refurbished_a22f98c8-9c70-4ad5-b6c8-3533cbb3af1b.e4399ae4cffbbab02215c4410a4018fd.jpeg",
        "displayLink": "www.walmart.com",
        "snippet": "iPhone SE in Apple iPhone - Walmart.com",
        "htmlSnippet": "<b>iPhone SE</b> in <b>Apple iPhone</b> - Walmart.com",
        "mime": "image/jpeg",
        "fileFormat": "image/jpeg",
        "image": {
          "contextLink": "https://www.walmart.com/browse/cell-phones/iphone-se/1105910_7551331_1127173_3393123",
          "height": 2000,
          "width": 2000,
          "byteSize": 255052,
          "thumbnailLink": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYlbgp6Yi8zKcAIUeewN214orQDjfISDwS1on-1ChoYLSo8HL-ORCiP4IA&s",
          "thumbnailHeight": 150,
          "thumbnailWidth": 150
        }
      },
      {
        "kind": "customsearch#result",
        "title": "Buy iPhone SE 64GB (PRODUCT)RED - Apple",
        "htmlTitle": "Buy <b>iPhone SE</b> 64GB (PRODUCT)RED - <b>Apple</b>",
        "link": "https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone-se-finish-select-202207-product-red?wid=2560&hei=1440&fmt=jpeg&qlt=95&.v=1655316263304",
        "displayLink": "www.apple.com",
        "snippet": "Buy iPhone SE 64GB (PRODUCT)RED - Apple",
        "htmlSnippet": "Buy <b>iPhone SE</b> 64GB (PRODUCT)RED - <b>Apple</b>",
        "mime": "image/",
        "fileFormat": "image/",
        "image": {
          "contextLink": "https://www.apple.com/shop/buy-iphone/iphone-se/4.7-inch-display-64gb-red-unlocked",
          "height": 1440,
          "width": 2560,
          "byteSize": 221638,
          "thumbnailLink": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQGAnIZ1P4D9sNX35YeDvVLuoGu1mvWj3l4JhTcmfsthpl0IDw8nuJKxw&s",
          "thumbnailHeight": 84,
          "thumbnailWidth": 150
        }
      },
      {
        "kind": "customsearch#result",
        "title": "Amazon.com: Apple iPhone SE (2nd Generation), US Version, 128GB ...",
        "htmlTitle": "Amazon.com: <b>Apple iPhone SE</b> (2nd Generation), US Version, 128GB ...",
        "link": "https://m.media-amazon.com/images/I/81wmQz6ukzL.jpg",
        "displayLink": "www.amazon.com",
        "snippet": "Amazon.com: Apple iPhone SE (2nd Generation), US Version, 128GB ...",
        "htmlSnippet": "Amazon.com: <b>Apple iPhone SE</b> (2nd Generation), US Version, 128GB ...",
        "mime": "image/jpeg",
        "fileFormat": "image/jpeg",
        "image": {
          "contextLink": "https://www.amazon.com/Apple-iPhone-SE-128GB-White/dp/B088NDPK5T",
          "height": 2560,
          "width": 2560,
          "byteSize": 297586,
          "thumbnailLink": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTSes5Kk94nc4fdbJ07qdyTaxkbHhn6xvJ-ayQd3zYUHx4V1XuzNafQDuo&s",
          "thumbnailHeight": 150,
          "thumbnailWidth": 150
        }
      },
      {
        "kind": "customsearch#result",
        "title": "Buy iPhone SE 256GB (PRODUCT)RED - Apple",
        "htmlTitle": "Buy <b>iPhone SE</b> 256GB (PRODUCT)RED - <b>Apple</b>",
        "link": "https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone-se-finish-select-202207-product-red?wid=5120&hei=2880&fmt=p-jpg&qlt=80&.v=1655316263304",
        "displayLink": "www.apple.com",
        "snippet": "Buy iPhone SE 256GB (PRODUCT)RED - Apple",
        "htmlSnippet": "Buy <b>iPhone SE</b> 256GB (PRODUCT)RED - <b>Apple</b>",
        "mime": "image/",
        "fileFormat": "image/",
        "image": {
          "contextLink": "https://www.apple.com/shop/buy-iphone/iphone-se/4.7-inch-display-256gb-red-unlocked",
          "height": 2880,
          "width": 5120,
          "byteSize": 212610,
          "thumbnailLink": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT0KWHOlzmaeXTXWkehk_aG1L31_VXycIztsC-1GIymVw-96gbUPqqDWXQ&s",
          "thumbnailHeight": 84,
          "thumbnailWidth": 150
        }
      }
    ]
  }
  
  
  const links = jsonData.items.map(item => item.link);
  
  // Create a JSON object with the extracted links
  const photoData = { links };
  
  export default photoData;
//   console.log(result);