import { useState } from 'react'
import { Routes, Route, redirect } from "react-router-dom";
import './App.css'
import IpForm from './form/searchForm'
import 'bootstrap/dist/css/bootstrap.min.css';
import SearchTable from './searchTable/searchTable';
import DetailsTab from './details/detailsTab';
// import detailInfo from './data/detailInfo';
import photoData from './data/photoData';
import axios from 'axios';

const eBayAPICall = () => {}
const eBayItemAPICall = () => {}

function App() {
  const [productItems, setProductItems] = useState([])
  const [detailInfo, setDetailInfo] = useState({})

  // const eBayAPICall = (
  //     keyword,
  //     category,
  //     news,
  //     used,
  //     unspecified,
  //     localPickup,
  //     freeShipping,
  //     distance,
  //     currentLocation,
  //     otherZip
  //   ) => {
  //     const condition = []
  //     if (news) {
  //       condition.push('New')
  //     }
  //     if (used) {
  //       condition.push('Used')
  //     }
  //     if (unspecified) {
  //       condition.push('Unspecified')
  //     }

  //     const shippingOptions = []
  //     if (localPickup) {
  //       shippingOptions.push('LocalPickupOnly')
  //     }
  //     if (freeShipping) {
  //       shippingOptions.push('FreeShippingOnly')
  //     }

  //     const From = currentLocation ? '90007' : otherZip
  //     const URL = `http://localhost:3000/search?Keyword=${keyword}&Category=${category}&Condition=${condition}&ShippingOptions=${shippingOptions}&Distance=${distance}&From=${From}`;
      
      
  //     // make get api call using axios
  //     axios.get(URL, {
  //       headers: {
  //          "Access-Control-Allow-Origin":"*",
  //          "Access-Control-Allow-Methods": "*",
  //          "Access-Control-Allow-Headers": "*"
  //         }
  //       })
  //     .then(function (response) {
  //       // handle success
  //       // console.log(response.data.findItemsAdvancedResponse[0].searchResult[0].item);
  //       setProductItems(response.data.findItemsAdvancedResponse[0].searchResult[0].item);
  //       redirect('/products');
  //     })
  //     .catch(function (error) {
  //       // handle error
  //       console.log(error);
  //     })
  //     .finally(function () {
  //       // always executed
  //     });
  // } 

  // const eBayItemAPICall = (itemId) => {
  //   const URL = `http://localhost:3000/getSingleItem/${itemId}`;
  //   axios.get(URL, {
  //     headers: {
  //        "Access-Control-Allow-Origin":"*",
  //        "Access-Control-Allow-Methods": "*",
  //        "Access-Control-Allow-Headers": "*"
  //       }
  //     })
  //   .then(function (response) {
  //     // handle success
  //     console.log(response.data.Item.CurrentPrice);
  //     setProductItems([]);
  //     setDetailInfo(response.data.Item);
  //   })
  //   .catch(function (error) {
  //     // handle error
  //     console.log(error);
  //   })
  //   .finally(function () {
  //     // always executed
      
  //   });
  // }

  return (
    <div className='App'>
      <IpForm eBayAPICall= {eBayAPICall} />
      <Routes>
        <Route path="products" element={<SearchTable products={productItems} eBayItemAPICall={eBayItemAPICall} />} />
        {/* <Route path="details" element={detailInfo && Object.keys(detailInfo).length!= 0 && Object.keys(photoData).length!= 0 && photoData?<DetailsTab detailInfo={detailInfo} photoData={photoData}/>: null} /> */}
      </Routes>
    
      {/* {console.log(sampleData)} */}
      {/* {productItems && productItems.length!= 0?<SearchTable products={productItems} eBayItemAPICall={eBayItemAPICall} />: null}
      <h2>Hello Adwait</h2>
      {detailInfo && Object.keys(detailInfo).length!= 0 && Object.keys(photoData).length!= 0 && photoData?<DetailsTab detailInfo={detailInfo} photoData={photoData}/>: null} */}
    </div>
  )
}


export default App
