import SearchRow from './ProductRow';


const SearchTable = ({ products, eBayItemAPICall }) => {
    return (
      <table>
        <thead>
          <tr>
            <th>Index</th>
            <th>Image</th>
            <th>Title</th>
            <th>Price</th>
            <th>Shipping</th>
            <th>Postal Code</th>
            <th>Returns Accepted</th>
          </tr>
        </thead>
        <tbody>
            {/* {console.log(products)} */}
          {products.map((product, index) => (
            <SearchRow key={product.itemId} product={product} index={index} eBayItemAPICall={eBayItemAPICall}/>
          ))}
        </tbody>
      </table>
    );
  };

export default SearchTable;
