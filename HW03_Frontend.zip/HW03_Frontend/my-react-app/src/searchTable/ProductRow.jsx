const SearchRow = ({ product, index, eBayItemAPICall }) => {
  const handleItemClick = (e) => {
    e.preventDefault();
    // console.log(product);
    eBayItemAPICall(product.itemId);
  }
  return (
    <tr>
      <td>{index + 1}</td>
      <td>
        <img src={product.galleryURL} alt={product.title} />
      </td>
      <td>
        <a href="#" onClick={handleItemClick} rel="noopener noreferrer" >
          {product.title}
        </a>
      </td>
      <td>${parseFloat(product.sellingStatus[0].currentPrice[0].__value__).toFixed(2)}</td>
      <td>{product.shippingInfo[0].shippingServiceCost[0].__value__ === '0.0' ? 'Free Shipping' : product.shippingInfo[0].shippingServiceCost[0].__value__ }</td>
      <td>{product.postalCode}</td>
      <td>{product.returnsAccepted[0] === 'true' ? 'Yes' : 'No'}</td>
    </tr>
  );
};

export default SearchRow;
