const { createLogger, transports, format } = require('winston');

const logger = createLogger({
  level: 'info', // You can set the desired log level (info, warn, error, etc.)
  format: format.combine(
    format.timestamp(),
    format.printf(({ timestamp, level, message }) => {
      return `${timestamp} ${level}: ${message}`;
    })
  ),
  transports: [
    new transports.Console(), // Logs will be displayed in the console
    new transports.File({ filename: 'error.log', level: 'error' }), // Logs error messages to a file
    new transports.File({ filename: 'combined.log' }), // Logs all messages to another file
  ],
});

module.exports = logger;
