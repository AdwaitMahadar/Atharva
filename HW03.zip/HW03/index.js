const express = require('express');
const axios = require('axios');
const app = express();
const session = require('express-session');
const cors = require('cors');
const mongoose = require('mongoose');

const logger = require('./middleware/logger'); // Import the logger
const search = require('./routes/search');
const item = require('./routes/item');
const photos = require('./routes/photos');
const shipping = require('./routes/shipping');
const saveWL = require('./routes/saveToWishlist');
const deleteWL = require('./routes/deleteFromWishlist');
const fetchWL = require('./routes/fetchFromWishlist');



app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: true
}));

app.use(cors());
app.use(express.json());
app.use('/search', search)
app.use('/getSingleItem', item)
app.use('/getPhotos', photos)
app.use('/getShipping', shipping)
app.use('/saveToWishlist', saveWL);
app.use('/deleteFromWishlist', deleteWL);
app.use('/fetchFromWishlist', fetchWL);

const dbUrl = 'mongodb://127.0.0.1:27017/571_HW03';

mongoose.connect(dbUrl).then(() => {
    logger.info("MongoDB connected");
}).catch((err) => {
    logger.error("MongoDB connection error", err);
});

const db = mongoose.connection;
db.on("error", console.error.bind(console, "connection error:"));
db.once("open", () => {
  logger.info("Database connected");
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  logger.info(`Server is running on port ${port}`);
});
