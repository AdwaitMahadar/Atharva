const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const productWishlist = new Schema({
    title: String,
    galleryURL: String,
    currentPrice: String,
    shippingServiceCost: String,
    favorite: Boolean,
});

module.exports = mongoose.model('ProductWishlist', productWishlist);