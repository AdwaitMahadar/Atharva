const express = require('express');
const axios = require('axios');
const router = express.Router();
const session = require('express-session');
const logger = require('../middleware/logger'); // Import the logger
const ProductWishlist = require('../models/wishlistItems');

router.use(express.json());


router.delete('/:itemId', async (req, res) => {
    try {
      // Access the eBay API data from the session
        const itemId = req.params.itemId;

        const result = await ProductWishlist.deleteOne({ _id: itemId });
        
        if (result.deletedCount === 1) {
            // res.json({ message: 'Item deleted successfully' });
            res.status(200).end();
        } else {
            res.status(404).json({ error: 'Item not found' });
        }

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'An error occurred' });
    }
  });
  
module.exports = router;