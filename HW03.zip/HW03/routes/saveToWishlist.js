const express = require('express');
const axios = require('axios');
const router = express.Router();
const session = require('express-session');
const logger = require('../middleware/logger'); // Import the logger
const ProductWishlist = require('../models/wishlistItems');

router.use(express.json());


router.post('/', async (req, res) => {
    try {
      // Access the eBay API data from the session
      // const newItemData = {
      //   title: 'Don 4',
      //   galleryURL: 'https://i.ebayimg.com/00/s/ODAwWDgwMA==/z/gPEAAOSwdPxlILse/$_12.JPG?',
      //   currentPrice: '1001',
      //   shippingServiceCost: 'Free',
      //   favorite: true,
      // };
      
      const newItemData = {
        title: req.body.title,
        galleryURL: req.body.galleryURL,
        currentPrice: req.body.currentPrice,
        shippingServiceCost: req.body.shippingServiceCost,
        favorite: req.body.favorite,
      };

    const newItem = await ProductWishlist.create(newItemData);

    res.status(201).json(newItem); // Respond with the newly created document
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'An error occurred' });
    }
  });
  
module.exports = router;