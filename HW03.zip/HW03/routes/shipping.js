const express = require('express');
const axios = require('axios');
const router = express.Router();
const session = require('express-session');
const logger = require('../middleware/logger'); // Import the logger

router.use(express.json());


router.get('/', async (req, res) => {
    try {
      // Access the eBay API data from the session
      const ebayData = req.session.ebayData;

      // Use the data as needed
      res.json(ebayData);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'An error occurred' });
    }
  });
  
module.exports = router;