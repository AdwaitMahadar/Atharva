const express = require('express');
const axios = require('axios');
const router = express.Router();
const session = require('express-session');
const logger = require('../middleware/logger'); // Import the logger
const ProductWishlist = require('../models/wishlistItems');

router.use(express.json());


router.get('/', async (req, res) => {
    try {
      // Access the eBay API data from the session
        const items = await ProductWishlist.find().exec();
        res.json(items);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'An error occurred' });
    }
  });
  
module.exports = router;