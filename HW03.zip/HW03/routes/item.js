const express = require('express');
const axios = require('axios');
const router = express.Router();
const OAuthToken = require('../ebay_oauth_token.js'); // Import the OAuthToken class
const logger = require('../middleware/logger'); // Import the logger

const client_id = 'AdwaitMa-CSCI571H-PRD-07284ce84-d303be4b'; // Replace with your eBay App Key
const client_secret = "PRD-7284ce849d94-10ff-40e7-953d-1a1c"

router.get('/:itemID', async (req, res) => {
  try {
    const itemID = req.params.itemID;
    // const itemID = '285415297037';
    
    const oauthToken = new OAuthToken(client_id, client_secret);
    const accessToken = await oauthToken.getApplicationToken();

    // Define the eBay API endpoint and request headers
    // const apiUrl = 'https://open.api.ebay.com/shopping?callname=GetSingleItem&responseencoding=JSON';
    const apiUrl = 'https://open.api.ebay.com/shopping';
    const headers = {
      'X-EBAY-API-IAF-TOKEN': accessToken,
    };

    // Parameters for the eBay API request
    const params = {
      'callname': 'GetSingleItem',
      'responseencoding': 'JSON',
      'appid': client_id,
      'siteid': 0,
      'version': 967,
      'ItemID': itemID,
      'IncludeSelector': 'Description,Details,ItemSpecifics',
    };

    // Make the eBay API request using Axios
    const response = await axios.get(apiUrl, {
      headers,
      params,
    });

    // Send the eBay API response back to the client
    res.json(response.data);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

module.exports = router;