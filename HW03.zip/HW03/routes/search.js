const express = require('express');
const axios = require('axios');
const router = express.Router();
const logger = require('../middleware/logger'); // Import the logger
const session = require('express-session');

const EBAY_API_URL = 'https://svcs.ebay.com/services/search/FindingService/v1';
const EBAY_APP_KEY = 'AdwaitMa-CSCI571H-PRD-07284ce84-d303be4b'; // Replace with your eBay App Key

router.get('/', async (req, res) => {
    try {
      const {
        Keyword,
        Category,
        Condition,
        ShippingOptions,
        Distance,
        From,
      } = req.query;

        // Keywords = 'Baby';
        // Category = ''; //'2984';
        // Condition = ''; //['New', 'Used'];
        // ShippingOptions = 'FreeShipping';
        // Distance = '10';
        // From = '90007';
  
      // Construct the eBay API URL with the specified parameters and optional filters.
      const optionalFilters = [];
      if (Distance) {
        optionalFilters.push(`itemFilter(0).name=MaxDistance&itemFilter(0).value=${Distance}`);
      }
      if (ShippingOptions) {
        if (ShippingOptions.includes('FreeShipping')) {
          optionalFilters.push(`itemFilter(${optionalFilters.length}).name=FreeShippingOnly&itemFilter(${optionalFilters.length}).value=true`);
          // optionalFilters.push(`itemFilter(1).name=FreeShippingOnly&itemFilter(1).value=true`);
        }
        if (ShippingOptions.includes('LocalPickup')) {
          optionalFilters.push(`itemFilter(${optionalFilters.length}).name=LocalPickupOnly&itemFilter(${optionalFilters.length}).value=true`);
          // optionalFilters.push(`itemFilter(2).name=LocalPickupOnly&itemFilter(2).value=true`);
        }
      }
  
      if (Condition !== undefined && Condition !== '') {
        const conditionValues = Condition.split(',');
        conditionValues.forEach((value, index) => {
          optionalFilters.push(`itemFilter(${optionalFilters.length}).name=Condition&itemFilter(${optionalFilters.length}).value=${value}`);
          // optionalFilters.push(`itemFilter(${index + 3}).name=condition&itemFilter(${index + 3}).value=${value}`);
        });
      }

      if (Category !== undefined && Category !== '') {
        optionalFilters.push(`categoryId=${Category}`);
      }

      const url = `${EBAY_API_URL}?OPERATION-NAME=findItemsAdvanced&SERVICE-VERSION=1.0.0&SECURITY-APPNAME=${EBAY_APP_KEY}&RESPONSE-DATA-FORMAT=JSON&REST-PAYLOAD&keywords=${Keyword}&paginationInput.entriesPerPage=10&buyerPostalCode=${From}&${optionalFilters.join('&')}`;//sortOrder=${SortBy}&${optionalFilters.join('&')}`;
      logger.info(`eBay API url: ${url}`);
  
      const response = await axios.get(url);
      const data = response.data;

      // Save the eBay API data to the session
      req.session.ebayData = data;
  
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: 'An error occurred while fetching eBay data' });
      logger.error(error);
    }
  });

  module.exports = router;