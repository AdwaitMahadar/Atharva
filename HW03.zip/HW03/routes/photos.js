// API-Key: AIzaSyDefGfSXNuK-9896RNqcHwGjUn-HIizXkI
// Custom Search Engine ID: f32b904abaadc4599
{/* <script async src="https://cse.google.com/cse.js?cx=f32b904abaadc4599">
</script>
<div class="gcse-search"></div> */}

const express = require('express');
const axios = require('axios');
const router = express.Router();
const logger = require('../middleware/logger'); // Import the logger

router.use(express.json());


router.get('/:productTitle', async (req, res) => {
    try {
      const productTitle = req.params.productTitle;
      // const productTitle = 'iPhone'
      const cx = 'f32b904abaadc4599';
      const imgSize = 'huge';
      const num = 8;
      const searchType = 'image';
      const apiKey = 'AIzaSyDefGfSXNuK-9896RNqcHwGjUn-HIizXkI';
  
      const googleSearchUrl = `https://www.googleapis.com/customsearch/v1?q=${productTitle}&cx=${cx}&imgSize=${imgSize}&num=${num}&searchType=${searchType}&key=${apiKey}`;
      // logger.info(`googleSearchUrl: ${googleSearchUrl}`);
  
      const response = await axios.get(googleSearchUrl);
  
      // Return the Google Custom Search API response as JSON
      res.json(response.data);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'An error occurred' });
    }
  });
  
module.exports = router;