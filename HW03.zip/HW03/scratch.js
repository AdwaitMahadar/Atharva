// router.get('/', async (req, res) => {
//     try {
//     //   const {
//     //     Keywords,
//     //     SortBy,
//     //     PriceRangeFrom,
//     //     PriceRangeTo,
//     //     SellerReturnsAccepted,
//     //     ShippingFree,
//     //     ExpeditedShipping,
//     //     Condition,
//     //   } = req.query;

//         logger.info('Search route accessed')
        
//         Keywords = 'iphone';
//         SortBy = 'BestMatch';
//         PriceRangeFrom = '200';
//         PriceRangeTo = '500';
//         SellerReturnsAccepted = 'false';
//         ShippingFree = 'false';
//         ExpeditedShipping = 'false';
//         Condition = 'New';


  
//       const optionalFilters = [];
//       if (PriceRangeFrom) {
//         optionalFilters.push(
//           `itemFilter(0).name=MinPrice&itemFilter(0).value=${PriceRangeFrom}&itemFilter(0).paramName=currency&itemFilter(0).paramValue=USD`
//         );
//       }
//       if (PriceRangeTo) {
//         optionalFilters.push(
//           `itemFilter(1).name=MaxPrice&itemFilter(1).value=${PriceRangeTo}&itemFilter(1).paramName=currency&itemFilter(1).paramValue=USD`
//         );
//       }
//       if (SellerReturnsAccepted) {
//         optionalFilters.push(`itemFilter(2).name=ReturnsAcceptedOnly&itemFilter(2).value=${SellerReturnsAccepted}`);
//       }
//       if (ShippingFree) {
//         optionalFilters.push(`itemFilter(3).name=FreeShippingOnly&itemFilter(3).value=${ShippingFree}`);
//       }
//       if (ExpeditedShipping) {
//         optionalFilters.push(`itemFilter(4).name=expeditedShippingType&itemFilter(4).value=Expedited`);
//       }
  
//       if (Condition) {
//         // Split condition values and create individual item filters
//         const conditionValues = Condition.split(',');
//         conditionValues.forEach((value, index) => {
//           optionalFilters.push(`itemFilter(${index + 5}).name=condition&itemFilter(${index + 5}).value=${value}`);
//         });
//       }
  
//       const url = `${EBAY_API_URL}?OPERATION-NAME=findItemsAdvanced&SERVICE-VERSION=1.0.0&SECURITY-APPNAME=${EBAY_APP_KEY}&RESPONSE-DATA-FORMAT=JSON&REST-PAYLOAD&keywords=${Keywords}&paginationInput.entriesPerPage=10&sortOrder=${SortBy}&${optionalFilters.join('&')}`;
//       logger.info(`eBay API url: ${url}`);
  
//       const response = await axios.get(url);
//       const data = response.data;
  
//       res.json(data);
//     } catch (error) {
//       res.status(500).json({ error: 'An error occurred while fetching eBay data' });
//     }
//   });